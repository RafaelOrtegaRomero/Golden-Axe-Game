/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forrestdamjuegos;

/**
 *
 * @author Rafae
 */
public class Enano extends Jugador{

    public Enano() {
        super();
        this.vida=3;
        this.fuerza=3;
        this.nombre="Enano";
        this.estaVivo=false;
    }
    
    
    
}
