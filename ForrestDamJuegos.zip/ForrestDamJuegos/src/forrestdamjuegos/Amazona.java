/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package forrestdamjuegos;

/**
 *
 * @author Rafae
 */
public class Amazona extends Jugador{

    public Amazona() {
        super();
        this.vida=6;
        this.fuerza=1;
        this.nombre="Amazona";
        this.estaVivo=false;
    }
    
}
